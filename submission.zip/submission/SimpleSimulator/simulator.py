def sext(n):
    # two's complement
    inverted = ''
    for bit in n:
            if bit == '0':
                    inverted += '1'
            else:
                    inverted += '0'

    result = ''
    carry = 1
    for bit in inverted[::-1]:
            if bit == '0' and carry == 1:
                    result = '1' + result
                    carry = 0
            elif bit == '1' and carry == 1:
                    result = '0' + result
            else:
                    result = bit + result

    # sext
    if(result[0]=='0'):
        extended_number = '0' * (32 - len(result)) + result
        return extended_number
    else: 
        extended_number = '1' * (32 - len(result)) + result
        return extended_number

def Bin_to_dec(x):
        if "." in x:
                arr = x.split(".")
                gt = arr[0][::-1]
                sum1 = 0
                for i in range(len(gt)):
                        d = int(gt[i])
                        sum1 = sum1 + d * (2**i)

                print(sum1)

                sum2 = 0
                st = arr[1]
                for r in range(len(st)):
                        e = int(st[r])
                        sum2 = sum2 + e * (2**(-r - 1))

                print(sum2)
                print(sum1 + sum2)
        else:
                sum1 = 0
                for i in range(len(x)):
                        d = int(x[i])
                        sum1 = sum1 + d * (2**i)

                print(sum1)


def Dec_to_bin(x):
    s = ""
    while x >= 1:
        d = str(x % 2)
        s = s + d
        x = x // 2
    
    return(s[::-1])

    
def tc(bin):
    
        global s
        s = ""
        for i in bin:
            if i == "0":
                s = s + "1"
            else:
                s = s + "0"

        p = -2
        carry = 0
        out = ""
        y = int(s[-1])
        if y == 0:
            out = "1" + out
            carry = 0
        else:
            out = "0" + out
            carry = 1

        while p >= -len(s):
            y = int(s[p])
            if (y == 1 and carry == 1):
                carry = 1
                out = "0" + out
            elif (y == 1 and carry == 0) or(y == 0 and carry == 1):
                carry = 0
                out = "1" + out
            elif y == 0 and carry == 0:
                carry = 0
                out = "0" + out
            p = p - 1

        if carry == 0:
            out = "0" + out
        elif carry == 1:
            out = "1" + out

        return (out)


def calsi(x):
    if x[0] == "1":
        df = tc(x)
        sum1 = 0
        fg = df[::-1]
        for i in range(len(fg)):
            d = int(fg[i])
            sum1 = sum1 + d * (2**i)

        return(-1 * sum1)
    else:
        sum1 = 0
        oh = x[::-1]
        for i in range(len(oh)):
             d = int(oh[i])
             sum1 = sum1 + d * (2**i)

        return(sum1)

    






def readfile(filename):    
        with open(filename, 'r') as f:     
                a=f.readlines()
        return a


r_add={"00000":"r0" , "00001":"r1", 
             "00010":"r2" , "00011":"r3",
             "00100":"r4" , "00101":"r5", 
             "00110":"r6" , "00111":"r7",
             "01000":"r8" , "01001":"r9",
             "01010":"r10", "01011":"r11",
             "01100":"r12", "01101":"r13",
             "01110":"r14", "01111":"r15",
             "10000":"r16", "10001":"r17",
             "10010":"r18", "10011":"r19",
             "10100":"r20", "10101":"r21",
             "10110":"r22", "10111":"r23",
             "11000":"r24", "11001":"r25",
             "11010":"r26", "11011":"r27",
             "11100":"r28", "11101":"r29",
             "11110":"r30", "11111":"r31",
             "5'b00110":"x6" }


r_val={"r1":0,"r2":0,
             "r3":0,"r4":0,
             "r5":0,"r6":0,
             "r7":0,"r8":0,
             "r9":0,"r10":0,
             "r11":0,"r12":0,
             "r13":0,"r14":0,
            "r15":0,"r16":0,
             "r17":0,
             "r18":0,"r19":0,
            "r20":0,"r21":0,
             "r22":0,"r23":0,
             "r24":0,"r25":0,
             "r26":0,
            "r27":0,"r28":0,
             "r29":0,"r30":0,
            "r31":0,"x6":0}

mem={}


def parse_instructions(a,r_val,r_add,mem):
    
    pc = int(0) 
    while(pc<len(a)):
        line=a[pc].strip("/n")

    
        ins=line[::-1]
        opcode = ins[0:6]
        
            
        if opcode == '0110011':    # R type
                rd    = ins[7:11]
                rs1 = ins[15:19]
                rs2 = ins[20:24]
                funct3 = ins[12:14]
                funct7 = ins[25:31]
                pc = pc + 1
                if (funct3 == '000' and funct7 == "0000000"):     #to fix here
                    #add
                    r_val[r_add[rd]] = r_val[r_add[rs1]] + r_val[r_add[rs2]]
                    
                        
                elif(funct3 == '000' and funct7 == "0100000"):
                    #sub
                    r_val[r_add[rd]] = r_val[r_add[rs1]] - r_val[r_add[rs2]]
                elif(funct3 == '001' and funct7 == "0000000"):
                    #sll
                    a=Bin_to_dec(Dec_to_bin(r_val[r_add[rs1]])[0:4])
                    r_val[r_add[rd]] = (r_val[r_add[rs1]]) << a     
                elif(funct3 == '010' and funct7 == "0000000"):
                    #slt
                    if ((r_val[r_add[rs1]])<(r_val[r_add[rs2]])):
                        r_val[r_add[rd]] = 1
                elif(funct3 == '011' and funct7 == "0000000"):
                    #sltu
                    if Dec_to_bin(r_val[r_add[rs1]]) < Dec_to_bin(r_val[r_add[rs2]]):
                        r_val[r_add[rd]] = 1
                    
                elif(funct3 == '100' and funct7 == "0000000"):
                    #xor
                    r_val[r_add[rd]]= (r_val[r_add[rs1]]) ^ (r_val[r_add[rs2]])
                    
                elif(funct3 == '101' and funct7 == "0000000"):
                    #srl
                    a=Bin_to_dec(Dec_to_bin(r_val[r_add[rs1]])[0:4])
                    r_val[r_add[rd]] = (r_val[r_add[rs1]]) >> a 
                    
                elif(funct3 == '110' and funct7 == "0000000"):
                    #or
                    r_val[r_add[rd]] = (r_val[r_add[rs1]])|(r_val[r_add[rs2]])
                elif(funct3 == '111' and funct7 == "0000000"):
                    #and
                    r_val[r_add[rd]] = (r_val[r_add[rs1]])&(r_val[r_add[rs2]])
                else:
                    return -1
                    
        elif opcode in ['0000011', '0010011', '1100111']:    # I type
                    
                    rd    = ins[7:11]
                    rs1 = ins[15:19]                    
                    funct3 = ins[12:14]
                    imm = ins[20:31]
                    if (funct3 == '000'):
                        #lw.
                        if (sext(r_val[r_add[rs1]]) + tc(imm)) in mem    :
                        
                            r_val[r_add[rd]] = mem[r_val[r_add[rs1]] + tc(imm)]
                        else:
                            m=Dec_to_bin(r_val[r_add[rs1]] +calsi(imm))
                            mem[m]="00000000000000000000000000000000"
                            r_val[r_add[rd]] = mem[r_val[r_add[rs1]] + tc(imm)]
                        
                    elif(funct3 == '001'):
                        #addi
                        r_val[r_add[rd]] = r_val[r_add[rs1]] + tc(imm)
                    elif(funct3 == '010'):
                        #sltiu
                        if Dec_to_bin(r_val[r_add[rs1]]) < (imm):
                            r_val[r_add[rd]] = 1
                    elif(funct3 == '011'):
                        #jalr
                        r_val[r_add[rd]] = pc + 4
                        pc = r_val["x6"]+sext(imm)
                        pc = str(Dec_to_bin(pc))
                        b = ""
                        for i in range(len(pc)):
                            b = b + "0" if i == len(pc) - 1 else b + pc[i]
                        pc = Bin_to_dec(b)     
                                 
                    else:
                        return -1
                        

        
                
        elif opcode == '0100011':    # S type
                    
                
                rs1 = ins[15:19]
                rs2 = ins[20:24]
                funct3 = ins[12:14]
                imm = ins[7:11] + ins[25:31]
                if (funct3 == '010'):
                    #sw
                
                    mem[sext(r_val[r_add[rs1]]) + (imm)] = r_val[r_add[rs2]]    
                    
                else:
                    return -1
                    
        elif opcode == '1100011':    # B type
            imm = ins[8:11] + ins[25:30] + ins[7] + ins[31]
            rs1=ins[15:19]
            rs2=ins[20:24]
            funct3=ins[12:14]
            if(funct3 == "000"):
                if (sext(r_val[r_add[rs2]]) == sext(r_val[r_add[rs1]])):
                    pc = pc + calsi(sext(imm + "0"))
             
            elif(funct3 == "001"):
                if(sext(r_val[r_add[rs2]]) != sext(r_val[r_add[rs1]])):
                    pc = pc + calsi(sext(imm + "0"))
             
            elif(funct3 == 100):
                if(sext(r_val[r_add[rs2]]) >= sext(r_val[r_add[rs1]])):
                    pc= pc + calsi(sext(imm + "0"))
                
            elif(funct3 == 101):
                if((r_val[r_add[rs2]]) >= (r_val[r_add[rs1]])):
                    pc= pc + calsi(sext(imm + "0"))
                
            elif(funct3 == 110):
                if(sext(Dec_to_bin(r_val[r_add[rs2]])) < sext(Dec_to_bin(r_val[r_add[rs1]]))):
                    pc = pc + calsi(sext(imm + "10"))
             
            elif(funct3 == 111):
                if(sext(Dec_to_bin(r_val[r_add[rs2]])) < sext(Dec_to_bin(r_val[r_add[rs1]]))):
                 pc = pc + calsi(sext(imm + "0"))
                    
            else:
                return -1
                    
                  
        elif opcode in ['0110111', '0010111']:    # U type
            imm=ins[12:31]
            rd=ins[7:11]
            if opcode=="0110111" :
                #lui
                 r_val[r_add[rd]] = pc + calsi(sext(imm))
                
                
            elif opcode == "0010111" :
                #auipc
                r_val[r_add[rd]] = tc(imm)
            else:
                return -1
                
        elif (opcode == '1101111'):    # J type
            rd = ins[7:11]
            imm = ins[21:30] + ins[20] + ins[12:19] + ins[31]
            r_val[r_add[rd]] = pc + 4

            temper = imm[20:1]
            temper += "0"
            pc += calsi(sext(temper))

            pc += calsi(sext(imm[20:1]))
        
        


def writefile(filename,data):
        with open(filename, 'w') as f:
                f.write(data)

print("at start")
print(r_val)
print(r_add)
print(mem)
print("new begining")

nani = readfile("E:\Projects\Python Projects\s_test1.txt")
parse_instructions(nani, r_val, r_add, mem)

print("_val ------------")
print(r_val)
print("_add ------------")
print(r_add)
print("_mem ------------")
print(mem)